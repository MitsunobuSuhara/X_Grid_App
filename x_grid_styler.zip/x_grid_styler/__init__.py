def classFactory(iface):
    from .x_grid_styler import X_Grid_Styler
    return X_Grid_Styler(iface)